from django.shortcuts import render, HttpResponse, redirect
from .models import Contact
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from blog.models import Post
from django.contrib.auth.models import User


# Create your views here.

def home(request):
    return render(request, 'home/home.html')
    # return HttpResponse("This is Home")

def contact(request):
    messages.error(request, 'Welcome to Contact')
    if request.method=='POST':
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        content = request.POST['content']
        print(name, email, phone, content)
        contact = Contact(name=name, email=email, phone=phone, content=content)
        contact.save()
    return render(request, 'home/contact.html')

def about(request):
    return render(request, 'home/about.html')

def search(request):
    query = request.GET['query']
    if len(query)>78:
        allposts = Post.objects.none()
    else:
        allpostsTitle = Post.objects.filter(title__icontains=query)
        allpostsContent = Post.objects.filter(content__icontains=query)
        allpostsAuthor = Post.objects.filter(author__icontains=query)
        allposts = allpostsTitle.union(allpostsContent,allpostsAuthor)
    if allposts.count() ==0:
        messages.warning(request, 'No search results found. Please refine your query')
    params = {'allPosts':allposts, 'query':query}
    return render(request, 'home/search.html', params)

def handleSignup(request):
    if request.method == 'POST':
        #Get the post parameters
        username = request.POST['username']
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']

        #check for errorneous input
        if len(username)>10:
            messages.error(request, 'Maximum 10 Charactor')
            return redirect('home')

        if not username.isalnum():
            messages.error(request, 'Username Should Only Contain letters and Numbers')
            return redirect('home')

        
        if pass1 !=pass2:
            messages.success(request, 'Password Match nahi Ho raha babuwa')
            return redirect('home')


        #Create the User
        myuser = User.objects.create_user(username, email, pass1)
        myuser.First_name = fname
        myuser.Last_name = lname
        myuser.save()
        messages.success(request, 'Your iCoder Account has been Successfully created')

        return redirect('home')
    else:
        return HttpResponse('404 Page Not Found')

def handleLogin(request):
    if request.method == 'POST':
        #Get the post parameters
        loginusername = request.POST['loginusername']
        loginpassword = request.POST['loginpass']

        user = authenticate(username=loginusername, password=loginpassword)

        if user is not None:
            login(request, user)
            messages.success(request, 'Successfully Logged In')
            return redirect('home')
        else:
            messages.success(request, 'Invalid Credentials, Please Try Again')
            return redirect('home')
       
    return HttpResponse('404 Page Not Found')

def handleLogout(request):
    logout(request)
    messages.success(request,'Successfully Logged out')
    return redirect('home')